#include<stdio.h>
#include<windows.h>
#define numero_vezes 5
main()
{
	SetConsoleOutputCP(65001);
 int n;  
 printf("Quantas tabuadas deseja visualizar? ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Valor inválido. Termine o programa.\n");
    }
    printf("\nTabuadas de 1 a %d \n\n", n, numero_vezes);
    for (int i = 1; i <= numero_vezes; ++i){
     for (int j = 1; j <= n; ++j){
     int resultado = j * i;	
     printf("%2d x %2d = %3d", j, i, resultado);
     if (j < n) printf("   "); 
	 }	
	 putchar('\n');    
	}
}
