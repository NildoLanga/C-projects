#include<stdio.h>
#include<windows.h>
main()
{
	SetConsoleOutputCP(65001);
const char AST = '*'; 
 const int N = 4; 
 
    for (int linha = 1; linha <= N; ++linha)            /* cada linha */
    {
        if (linha == 1 || linha == N)                  /* primeira ou última */
        {
            /* imprime N asteriscos consecutivos */
            for (int col = 1; col <= N; ++col)
                printf("%c", AST);
        }
        else                                            
        {
            printf("%c", AST);                           /* as colunas 2 e 3 so sao preenchidas no inicio e no fim */
            for (int col = 2; col < N; ++col)           /*a condiçao que esvazia as linhas do meio */
                printf(" ");
            printf("%c", AST);                           /* último asterisco  */
        }

        putchar('\n');                                  /* fim da linha    */
    }

  
}
