#include<stdio.h>
#include<windows.h>
#include <math.h> 
main()
{
	SetConsoleOutputCP(65001);
double raio;    /* raio introduzido pelo utilizador */
    double area;    /* área por  calculadr */

    printf("=== Cálculo da Área do Círculo ===\n");
    printf("Introduza o raio (0 para terminar). Valores negativos são inválidos.\n\n");
 /* Enquanto o utilizador não digitar 0, o programa continua */
    while (1) {
        printf("Raio: ");
        if (scanf("%lf", &raio) != 1) {          /* leitura falhou */
            printf("Entrada não numérica. Programa abortado.\n");
            break;
        }

        /* Caso o utilizador queira terminar */
        if (raio == 0.0) {
            printf("\nFim do programa.\n");
            break;                               /* sai do while */
        }

        /* Raio negativo → aviso e volta ao início do loop */
        if (raio < 0.0) {
            printf("Raio inválido. Informe um valor maior ou igual a zero.\n\n");
            continue;                            /* obriga o programa a fazer a validaçao incial de novo 
			                                     volta para o loop while e recomeça a validaçao*/
        }

        
        area = M_PI * raio * raio;

        printf("Área = %.4f\n\n", area);          /* quatro casas decimais */
    }

    
}
